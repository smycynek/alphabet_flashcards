self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "18da201320bbed73ab575132b4d89b89",
    "url": "/abc/index.html"
  },
  {
    "revision": "e654a6366857d44f7744",
    "url": "/abc/static/css/main.e94f8d2d.chunk.css"
  },
  {
    "revision": "3a4e93f5a93b46a99250",
    "url": "/abc/static/js/2.2a7f292d.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/abc/static/js/2.2a7f292d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e654a6366857d44f7744",
    "url": "/abc/static/js/main.d5c497d2.chunk.js"
  },
  {
    "revision": "f247832df1ee5ab2f791",
    "url": "/abc/static/js/runtime-main.986360f8.js"
  },
  {
    "revision": "ed4279e22cf82d6100be4d0c884ad4c7",
    "url": "/abc/static/media/github.ed4279e2.svg"
  }
]);